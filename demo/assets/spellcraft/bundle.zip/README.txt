spellcraft — PixelForge export

spellcraft.png: transparent RGBA sprite sheet
spellcraft.atlas.json: TexturePacker-style frames and named animation sequences
spellcraft.css: CSS classes with per-frame timing
frames/: individual PNGs
animations/: animated PNGs (APNG)
spellcraft.pixel.json: editable source
player.js: dependency-free Canvas player
preview.html: open directly in a browser, or serve this folder

Canvas: import { SpritePlayer } from './player.js';
const player = await SpritePlayer.load(canvas, './spellcraft.atlas.json');
player.play('ember');

CSS: <link rel="stylesheet" href="spellcraft.css">
<span class="pf-spellcraft pf-spellcraft-ember"></span>
