warden — PixelForge export

warden.png: transparent RGBA sprite sheet
warden.atlas.json: TexturePacker-style frames and named animation sequences
warden.css: CSS classes with per-frame timing
frames/: individual PNGs
animations/: animated PNGs (APNG)
warden.pixel.json: editable source
player.js: dependency-free Canvas player
preview.html: open directly in a browser, or serve this folder

Canvas: import { SpritePlayer } from './player.js';
const player = await SpritePlayer.load(canvas, './warden.atlas.json');
player.play('idle');

CSS: <link rel="stylesheet" href="warden.css">
<span class="pf-warden pf-warden-idle"></span>
