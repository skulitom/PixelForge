knight — PixelForge export

knight.png: transparent RGBA sprite sheet
knight.atlas.json: TexturePacker-style frames and named animation sequences
knight.css: CSS classes with per-frame timing
frames/: individual PNGs
animations/: animated PNGs (APNG)
knight.pixel.json: editable source
player.js: dependency-free Canvas player
preview.html: open directly in a browser, or serve this folder

Canvas: import { SpritePlayer } from './player.js';
const player = await SpritePlayer.load(canvas, './knight.atlas.json');
player.play('idle');

CSS: <link rel="stylesheet" href="knight.css">
<span class="pf-knight pf-knight-idle"></span>
