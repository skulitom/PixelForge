terrain — PixelForge export

terrain.png: transparent RGBA sprite sheet
terrain.atlas.json: TexturePacker-style frames and named animation sequences
terrain.css: CSS classes with per-frame timing
frames/: individual PNGs
animations/: animated PNGs (APNG)
terrain.pixel.json: editable source
player.js: dependency-free Canvas player
preview.html: open directly in a browser, or serve this folder

Canvas: import { SpritePlayer } from './player.js';
const player = await SpritePlayer.load(canvas, './terrain.atlas.json');
player.play('earth');

CSS: <link rel="stylesheet" href="terrain.css">
<span class="pf-terrain pf-terrain-earth"></span>
