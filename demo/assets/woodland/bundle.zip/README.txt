woodland — PixelForge export

woodland.png: transparent RGBA sprite sheet
woodland.atlas.json: TexturePacker-style frames and named animation sequences
woodland.css: CSS classes with per-frame timing
frames/: individual PNGs
animations/: animated PNGs (APNG)
woodland.pixel.json: editable source
player.js: dependency-free Canvas player
preview.html: open directly in a browser, or serve this folder

Canvas: import { SpritePlayer } from './player.js';
const player = await SpritePlayer.load(canvas, './woodland.atlas.json');
player.play('oak');

CSS: <link rel="stylesheet" href="woodland.css">
<span class="pf-woodland pf-woodland-oak"></span>
