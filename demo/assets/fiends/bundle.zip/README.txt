fiends — PixelForge export

fiends.png: transparent RGBA sprite sheet
fiends.atlas.json: TexturePacker-style frames and named animation sequences
fiends.css: CSS classes with per-frame timing
frames/: individual PNGs
animations/: animated PNGs (APNG)
fiends.pixel.json: editable source
player.js: dependency-free Canvas player
preview.html: open directly in a browser, or serve this folder

Canvas: import { SpritePlayer } from './player.js';
const player = await SpritePlayer.load(canvas, './fiends.atlas.json');
player.play('crawler');

CSS: <link rel="stylesheet" href="fiends.css">
<span class="pf-fiends pf-fiends-crawler"></span>
