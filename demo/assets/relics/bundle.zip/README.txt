relics — PixelForge export

relics.png: transparent RGBA sprite sheet
relics.atlas.json: TexturePacker-style frames and named animation sequences
relics.css: CSS classes with per-frame timing
frames/: individual PNGs
animations/: animated PNGs (APNG)
relics.pixel.json: editable source
player.js: dependency-free Canvas player
preview.html: open directly in a browser, or serve this folder

Canvas: import { SpritePlayer } from './player.js';
const player = await SpritePlayer.load(canvas, './relics.atlas.json');
player.play('brazier');

CSS: <link rel="stylesheet" href="relics.css">
<span class="pf-relics pf-relics-brazier"></span>
