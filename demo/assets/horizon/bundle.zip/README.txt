horizon — PixelForge export

horizon.png: transparent RGBA sprite sheet
horizon.atlas.json: TexturePacker-style frames and named animation sequences
horizon.css: CSS classes with per-frame timing
frames/: individual PNGs
animations/: animated PNGs (APNG)
horizon.pixel.json: editable source
player.js: dependency-free Canvas player
preview.html: open directly in a browser, or serve this folder

Canvas: import { SpritePlayer } from './player.js';
const player = await SpritePlayer.load(canvas, './horizon.atlas.json');
player.play('moonrise');

CSS: <link rel="stylesheet" href="horizon.css">
<span class="pf-horizon pf-horizon-moonrise"></span>
