wayfarer — PixelForge export

wayfarer.png: transparent RGBA sprite sheet
wayfarer.atlas.json: TexturePacker-style frames and named animation sequences
wayfarer.css: CSS classes with per-frame timing
frames/: individual PNGs
animations/: animated PNGs (APNG)
wayfarer.pixel.json: editable source
player.js: dependency-free Canvas player
preview.html: open directly in a browser, or serve this folder

Canvas: import { SpritePlayer } from './player.js';
const player = await SpritePlayer.load(canvas, './wayfarer.atlas.json');
player.play('fern');

CSS: <link rel="stylesheet" href="wayfarer.css">
<span class="pf-wayfarer pf-wayfarer-fern"></span>
